const prompt=require('prompt-sync')();
// Function to prompt the user for politician details
function enterPoliticianDetails() {
  const name = prompt('Enter politician name:');
  const votes = parseInt(prompt('Enter number of votes:'));
  const money = parseFloat(prompt('Enter amount of money:'));

  return { name, votes, money };
}

// Function to find the politician with the maximum votes
function getMaxVotesPolitician(politicians) {
  let maxVotes = 0;
  let maxVotesPolitician = null;

  politicians.forEach(politician => {
    if (politician.votes > maxVotes) {
      maxVotes = politician.votes;
      maxVotesPolitician = politician;
    }
  });

  return maxVotesPolitician;
}

// Function to find the politician with the maximum money
function getMaxMoneyPolitician(politicians) {
  let maxMoney = 0;
  let maxMoneyPolitician = null;

  politicians.forEach(politician => {
    if (politician.money > maxMoney) {
      maxMoney = politician.money;
      maxMoneyPolitician = politician;
    }
  });

  return maxMoneyPolitician;
}

// Prompt the user for the number of politicians
const numPoliticians = parseInt(prompt('Enter the number of politicians:'));

// Array to store the politicians
const partyPoliticians = [];

// Loop to enter politician details
for (let i = 0; i < numPoliticians; i++) {
  console.log(`Enter details for Politician ${i + 1}:`);
  const politician = enterPoliticianDetails();
  partyPoliticians.push(politician);
}

// Find the politician with the maximum votes
const politicianWithMaxVotes = getMaxVotesPolitician(partyPoliticians);
console.log('Politician with the maximum votes:', politicianWithMaxVotes);

// Find the politician with the maximum money
const politicianWithMaxMoney = getMaxMoneyPolitician(partyPoliticians);
console.log('Politician with the maximum money:', politicianWithMaxMoney);
