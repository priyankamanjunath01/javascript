const prompt = require('prompt-sync')();
const MongoClient = require('mongodb').MongoClient;

// Function to prompt the user for politician details
async function enterPoliticianDetails() {
  const name = prompt('Enter politician name:');
  const votes = parseInt(prompt('Enter number of votes:'));
  const money = parseFloat(prompt('Enter amount of money:'));

  return { name, votes, money };
}

// Function to find the politician with the maximum votes
function getMaxVotesPolitician(politicians) {
  let maxVotes = 0;
  let maxVotesPolitician = null;

  politicians.forEach(politician => {
    if (politician.votes > maxVotes) {
      maxVotes = politician.votes;
      maxVotesPolitician = politician;
    }
  });

  return maxVotesPolitician;
}

// Function to find the politician with the maximum money
function getMaxMoneyPolitician(politicians) {
  let maxMoney = 0;
  let maxMoneyPolitician = null;

  politicians.forEach(politician => {
    if (politician.money > maxMoney) {
      maxMoney = politician.money;
      maxMoneyPolitician = politician;
    }
  });

  return maxMoneyPolitician;
}

async function run() {
  // Connect to the MongoDB database
  const uri = 'mongodb+srv://priyankacmbsc22:12345@cluster0.r0gyqwl.mongodb.net/?retryWrites=true&w=majority';
  const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
  await client.connect();
  console.log('Connected to MongoDB');

  try {
    // Prompt the user for the number of politicians
    const numPoliticians = parseInt(prompt('Enter the number of politicians:'));

    // Array to store the politicians
    const partyPoliticians = [];

    // Loop to enter politician details
    for (let i = 0; i < numPoliticians; i++) {
      console.log(`Enter details for Politician ${i + 1}:`);
      const politician = await enterPoliticianDetails();
      partyPoliticians.push(politician);
    }

    // Insert the politicians into the MongoDB collection
    const politiciansCollection = client.db('your-database-name').collection('politicians');
    await politiciansCollection.insertMany(partyPoliticians);
    console.log('Politicians inserted into MongoDB');

    // Find the politician with the maximum votes
    const politicianWithMaxVotes = getMaxVotesPolitician(partyPoliticians);
    console.log('Politician with the maximum votes:', politicianWithMaxVotes);

    // Find the politician with the maximum money
    const politicianWithMaxMoney = getMaxMoneyPolitician(partyPoliticians);
    console.log('Politician with the maximum money:', politicianWithMaxMoney);
  } finally {
    // Close the MongoDB connection
    await client.close();
    console.log('Disconnected from MongoDB');
  }
}

// Run the program
run().catch(console.error);