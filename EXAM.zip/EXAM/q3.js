const prompt = require('prompt-sync')();
const mongoose = require('mongoose');

// Define the Politician schema
const politicianSchema = new mongoose.Schema({
  name: { type: String, required: true },
  votes: { type: Number, required: true },
  money: { type: Number, required: true }
});

// Create the Politician model
const Politician = mongoose.model('Politician', politicianSchema);

// Function to prompt the user for politician details
function enterPoliticianDetails() {
  const name = prompt('Enter politician name:');
  const votes = parseInt(prompt('Enter number of votes:'));
  const money = parseFloat(prompt('Enter amount of money:'));

  return { name, votes, money };
}

async function performCRUD() {
  try {
    // Connect to MongoDB
    await mongoose.connect('mongodb+srv://priyankacmbsc22:12345@cluster0.r0gyqwl.mongodb.net/your-database-name', {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('Connected to MongoDB');

    // Prompt the user for the number of politicians
    const numPoliticians = parseInt(prompt('Enter the number of politicians:'));

    // Create politicians
    for (let i = 0; i < numPoliticians; i++) {
      console.log(`Enter details for Politician ${i + 1}:`);
      const politician = enterPoliticianDetails();
      const newPolitician = new Politician(politician);
      await newPolitician.save();
      console.log(`Politician ${i + 1} saved`);
    }

    // Read all politicians
    const allPoliticians = await Politician.find();
    console.log('All Politicians:', allPoliticians);

    // Find the politician with the maximum votes
    const politicianWithMaxVotes = getMaxVotesPolitician(allPoliticians);
    console.log('Politician with the maximum votes:', politicianWithMaxVotes);

    // Find the politician with the maximum money
    const politicianWithMaxMoney = getMaxMoneyPolitician(allPoliticians);
    console.log('Politician with the maximum money:', politicianWithMaxMoney);

    // Update a politician
    const politicianToUpdate = allPoliticians[0];
    politicianToUpdate.votes += 10;
    await politicianToUpdate.save();
    console.log('Updated politician:', politicianToUpdate);

    // Delete a politician
    const politicianToDelete = allPoliticians[1];
    await Politician.findByIdAndDelete(politicianToDelete._id);
    console.log('Deleted politician:', politicianToDelete);
  } catch (error) {
    console.error('Error:', error);
  } finally {
    // Disconnect from MongoDB
    await mongoose.disconnect();
    console.log('Disconnected from MongoDB');
  }
}

// Run the CRUD operations
performCRUD();
