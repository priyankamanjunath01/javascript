class Voter {
    constructor(name, age, gender, constituency) {
      this.name = name;
      this.age = age;
      this.gender = gender;
      this.constituency = constituency;
    }
  }
  
  class Constituency {
    constructor(name) {
      this.name = name;
      this.voters = [];
    }
  
    addVoter(voter) {
      this.voters.push(voter);
    }
  
    calculateGenderPercentage() {
      let total = this.voters.length;
      let maleCount = this.voters.filter(voter => voter.gender === "Male").length;
      let femaleCount = this.voters.filter(voter => voter.gender === "Female").length;
  
      if (total > 0) {
        let malePercentage = (maleCount / total) * 100;
        let femalePercentage = (femaleCount / total) * 100;
        return { malePercentage, femalePercentage };
      }
  
      return { malePercentage: 0, femalePercentage: 0 };
    }
  }
  
  function main() {
    const constituency = new Constituency("Example Constituency");
  
    // Add sample voters
    constituency.addVoter(new Voter("John", 25, "Male", constituency.name));
    constituency.addVoter(new Voter("Jane", 30, "Female", constituency.name));
    constituency.addVoter(new Voter("Mark", 35, "Male", constituency.name));
    constituency.addVoter(new Voter("Emily", 28, "Female", constituency.name));
  
    // Calculate and print gender percentage
    let { malePercentage, femalePercentage } = constituency.calculateGenderPercentage();
    console.log(`Male Percentage: ${malePercentage}%`);
    console.log(`Female Percentage: ${femalePercentage}%`);
  }
  
  main();
  