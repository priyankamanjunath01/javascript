const mongoose = require('mongoose');

// Define the Voter schema
const voterSchema = new mongoose.Schema({
  name: String,
  age: Number,
  gender: String,
  constituency: String
});

// Create the Voter model
const Voter = mongoose.model('Voter', voterSchema);

async function main() {
  try {
    // Connect to MongoDB
    await mongoose.connect('mongodb+srv://priyankacmbsc22:12345@cluster0.r0gyqwl.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');

    // Add sample voters
    const constituency = 'Example Constituency';
    await Voter.insertMany([
      { name: 'John', age: 25, gender: 'Male', constituency },
      { name: 'Jane', age: 30, gender: 'Female', constituency },
      { name: 'Mark', age: 35, gender: 'Male', constituency },
      { name: 'Emily', age: 28, gender: 'Female', constituency }
    ]);
    console.log('Voters inserted into the collection');

    // Print all voters
    const fetchedVoters = await Voter.find();
    console.log('All Voters:');
    fetchedVoters.forEach(voter => {
      console.log(voter.toString());
    });

    // Calculate and print gender percentage
    let { malePercentage, femalePercentage } = calculateGenderPercentage(fetchedVoters);
    console.log(`Male Percentage: ${malePercentage}%`);
    console.log(`Female Percentage: ${femalePercentage}%`);

    // Update age for a voter
    await Voter.updateOne({ name: 'John' }, { age: 26 });
    console.log('Age updated for voter: John');

    // Delete a voter
    await Voter.deleteOne({ name: 'Jane' });
    console.log('Voter Jane deleted');
  } catch (error) {
    console.error('Error:', error);
  } finally {
    // Disconnect from MongoDB
    await mongoose.disconnect();
    console.log('Disconnected from MongoDB');
  }
}

function calculateGenderPercentage(voters) {
  let total = voters.length;
  let maleCount = voters.filter(voter => voter.gender === 'Male').length;
  let femaleCount = voters.filter(voter => voter.gender === 'Female').length;

  if (total > 0) {
    let malePercentage = (maleCount / total) * 100;
    let femalePercentage = (femaleCount / total) * 100;
    return { malePercentage, femalePercentage };
  }

  return { malePercentage: 0, femalePercentage: 0 };
}

main();
